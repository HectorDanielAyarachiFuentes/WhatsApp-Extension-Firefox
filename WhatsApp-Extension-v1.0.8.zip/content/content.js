/**
 * @file content/content.js
 * @description The main entry point for the content script. Starts Observers and connects all modules.
 *              Auto-dismissal of the "WhatsApp open in another window" dialog is handled
 *              by content/autoDismiss.js (runs at document_start).
 * @context Evaluated last in the content_scripts array.
 */
window.WA = window.WA || {};


(function () {
  let initAttempts = 0;
  const waitForApp = setInterval(() => {
    initAttempts++;
    const app = document.querySelector('#app');
    const isLoaded = document.querySelector('#side, #pane-side, [data-testid="chat-list"], header');
    if (app && isLoaded) {
      clearInterval(waitForApp);
      console.log('[WA Sidebar] WhatsApp detectado, iniciando escaneo...');
      init();
    }
    if (initAttempts > 300) {
      clearInterval(waitForApp);
    }
  }, 400);

  function init() {
    const isBackground = (window.name === 'wa-background-iframe');

    // Debounce el callback del observer: WhatsApp muta el DOM muy frecuentemente
    // durante renders reactivos. Sin debounce se envía un mensaje al background
    // en cada micro-mutación, saturando el canal de mensajes.
    let _scanDebounceTimer = null;
    const observer = new MutationObserver(() => {
      clearTimeout(_scanDebounceTimer);
      _scanDebounceTimer = setTimeout(() => window.WA.scanner.scanUnreadChats(), 250);
    });
    let observerContainer = null;

    const tryObserve = () => {
      const containers = document.querySelectorAll(window.WA.SELECTORS.chatListContainer);
      if (containers.length > 0) {
        const container = containers[containers.length - 1]; 
        if (container !== observerContainer) {
          if (observerContainer) observer.disconnect();
          observer.observe(container, { childList: true, subtree: true, characterData: true });
          observerContainer = container;
        }
      }
    };

    tryObserve();
    const _tryObserveInterval = setInterval(tryObserve, 1500); // eslint-disable-line no-unused-vars
    setTimeout(() => window.WA.scanner.scanUnreadChats(), 150);

    // Heartbeat periódico para garantizar detección rápida de mensajes incluso si el navegador throttling los eventos
    setInterval(() => {
      if (window.WA.scanner && window.WA.scanner.scanUnreadChats) {
        window.WA.scanner.scanUnreadChats();
      }
    }, 2500);

    // Combo Opción 2: Al presionar "Activar", dejamos que WhatsApp ejecute su sincronización
    // real de mensajes, y 400ms después se simula el clic en la 'X' para que WhatsApp guarde
    // la bandera permanente de descarte y no vuelva a mostrar el cartel nunca más.
    document.addEventListener('click', (e) => {
      const target = e.target;
      if (!target) return;
      const text = (target.textContent || '').trim().toLowerCase();
      if (text === 'activar' || text.startsWith('activar')) {
        const card = target.closest('div');
        const cardContainer = card ? card.closest('div[role="alert"], div[role="region"], div') : null;
        const banner = cardContainer || card;
        if (banner) {
          const bannerText = (banner.textContent || '').toLowerCase();
          if (bannerText.includes('sincroniz') || bannerText.includes('segundo plano')) {
            setTimeout(() => {
              const closeBtn = banner.querySelector('button:has(svg), [data-icon="x"], [data-testid="x"], [aria-label*="Cerrar"], [aria-label*="Close"]') ||
                               document.querySelector('[data-icon="x"], [data-testid="x"]');
              if (closeBtn) {
                const btn = closeBtn.closest('button') || closeBtn;
                btn.click?.();
              }
            }, 400);
          }
        }
      }
    }, true);

    if (isBackground) {
      console.log('[WA Sidebar] Ejecutando en segundo plano (modo notificaciones).');
      return;
    }

    console.log('[WA Sidebar] Ejecutando en la barra lateral interactiva.');
    setInterval(() => {
      window.WA.resizer?.setupResizer?.();
      window.WA.resizer?.checkCollapseState?.();
      window.WA.miniChats?.renderMiniChats?.();
    }, 500);
  }

  browser.runtime.onMessage.addListener(async (message) => {
    if (message.type === 'quick_reply') {
      await window.WA.quickReply.handleQuickReply(message.contact, message.message);
    }
  });

  window.addEventListener('message', async (event) => {

    if (event.data && event.data.type === 'quick_reply') {
      await window.WA.quickReply.handleQuickReply(event.data.contact, event.data.message);
    } else if (event.data && event.data.type === 'toggle_internal_panel') {
      const resizer = document.getElementById('wa-extension-resizer');
      if (resizer && resizer.parentElement) {
         const leftPane = resizer.parentElement;
         const currentWidth = leftPane.getBoundingClientRect().width;
         const marginRight = parseInt(getComputedStyle(leftPane).marginRight) || 0;
         
         if (currentWidth < 150 || marginRight < -100) {
            leftPane.style.flexBasis = `350px`;
            leftPane.style.maxWidth = `350px`;
            leftPane.style.width = `350px`;
            leftPane.style.minWidth = `350px`;
            leftPane.style.marginLeft = `0px`;
            leftPane.style.marginRight = `0px`;
            leftPane.style.visibility = '';
            leftPane.classList.remove('wa-is-collapsed');
            resizer.style.left = 'auto';
            resizer.style.right = '-8px';
         } else {
            leftPane.style.flexBasis = `300px`;
            leftPane.style.maxWidth = `300px`;
            leftPane.style.width = `300px`;
            leftPane.style.minWidth = `300px`;
            leftPane.style.marginLeft = `0px`;
            leftPane.style.marginRight = `-300px`; 
            leftPane.style.visibility = '';
            leftPane.classList.add('wa-is-collapsed');
            resizer.style.left = '0px';
            resizer.style.right = 'auto';
         }
      }
    }
  });
})();
